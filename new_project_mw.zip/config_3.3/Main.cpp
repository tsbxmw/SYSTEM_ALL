#include "config.h"

int  main()
{
	
	config_ftp_mail();
	return 0;
}

