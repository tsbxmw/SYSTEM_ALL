﻿#include "config_mysql.h"
#include <iostream>
using namespace std;
void mysql_open()
{
	string insert_values[100];
	insert_values[0] = "10.63.220.2";
	insert_values[1] = "P809V50";
	insert_values[2] = "12345678";
	insert_values[3] = "NULL";
	insert_values[4] = "BUSY";
	MYSQL mysql ;
	if(!init_db(&mysql))
	{
		cout<<"|-- connect successful ! "<<endl;
		if(find_db(&mysql,DB_NAME) && select_db(&mysql,DB_NAME))
		{
			find_table(&mysql,TABLE_SER);
			find_table(&mysql,TABLE_CLI);
			cout<<"|-- OK！ init over ！"<<endl;
			find_ip_pro_line(&mysql,TABLE_SER,insert_values);
			
		}
	}
}