/*
	//config server exe file
	//source dbg by mw10192582
	//use the default source supplied by mw
	//contact to author : meng.wei@zte.com.cn

*/

#include "server.h"

#define SERVER_NAME "config_server"
